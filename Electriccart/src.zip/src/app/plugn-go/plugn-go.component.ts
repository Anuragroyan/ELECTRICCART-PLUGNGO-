import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plugn-go',
  templateUrl: './plugn-go.component.html',
  styleUrls: ['./plugn-go.component.css']
})
export class PlugnGoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
