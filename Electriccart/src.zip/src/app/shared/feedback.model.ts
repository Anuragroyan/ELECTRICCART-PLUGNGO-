export class Feedback {
    _id: string;
    Names: string
    email_id: string;
    feedback: string;
}
