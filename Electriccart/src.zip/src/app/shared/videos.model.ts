export class Videos {
    _id: string;
    names: string;
    video: string;
    views: number;
}

