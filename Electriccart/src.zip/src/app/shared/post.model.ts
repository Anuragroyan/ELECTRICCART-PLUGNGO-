export class Post {
    _id: string;
    topic: string;
    date: string;
    By: string;
    place: string;
    comment: string;
    content: string;
    like: Number;
    dislike: Number;
}
