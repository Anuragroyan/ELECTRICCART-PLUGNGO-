export class Register {
    _id: string;
    first_name: string;
    last_name: string;
    email_id : string;
    contact: number;
    password: string;
}
