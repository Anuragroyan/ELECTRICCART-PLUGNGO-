import { Videos } from './videos.model';

describe('Videos', () => {
  it('should create an instance', () => {
    expect(new Videos()).toBeTruthy();
  });
});
